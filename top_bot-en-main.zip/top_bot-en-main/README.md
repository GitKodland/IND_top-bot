# top_bot
Hi!

You will find all the functions for the your chatbot in the bot_logic file

The settings file contains a dictionary with all the settings for the bot

The bot itself should be created in the main.py file
