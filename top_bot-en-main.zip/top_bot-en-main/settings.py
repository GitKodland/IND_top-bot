settings = {
    "prefix": ">",
    "TOKEN": "THE TOKEN WILL BE STORED HERE"
}
